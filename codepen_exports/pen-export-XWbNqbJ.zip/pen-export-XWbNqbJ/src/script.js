var canvas = document.getElementById("canvas");
var ctx = canvas.getContext("2d");
ctx.scale(3,3);
// ctx.font = "48px serif";
// ctx.fillText("Hello world", 50, 100);
const paint = (ctx) => {
  ctx.clearRect(0, 0, 300, 300);
  const font = document.getElementById('font').value;
  const text = document.getElementById('text').value;
  const x = document.getElementById('x').value;
  const y = document.getElementById('y').value;
  const maxWidth = document.getElementById('maxWidth').value;
  ctx.font = font;
  ctx.fillText(text, parseInt(x), parseInt(y), parseInt(maxWidth));
  ctx.font = '15px sans';
  ctx.fillText(`x:${x} y:${y} maxWidth:${maxWidth}`, 10, 90);
}
const form = document.getElementById("form");
paint(ctx);
form.addEventListener('input', () => paint(ctx));